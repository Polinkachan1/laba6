#include "application.h"

int main(int argc, char *argv[])
{
    TApplication app(argc, argv);
    return app.exec();
}