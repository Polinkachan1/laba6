#include "complex.h"

#ifndef NUMBER_H
#define NUMBER_H

typedef TComplex number;

#endif //NUMBER_H